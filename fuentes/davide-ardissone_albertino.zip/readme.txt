ALBERTINO Truetype Font
-----------------------
v. 1.0 - May 22, 2008
Typeface (c) Davide Ardissone 2008. All Rights Reserved
-----------------------

TERMS OF USE
- Licence: Free for personal, non-commercial use.
  Under NO circumstances may this font be sold for a profit.
  If you want to use it for commercial purposes, please contact 
  me first (davric74@gmail.com).

- This font package (font file + documentation) may not be
  modified.

- This font is freely distributable, but you have to keep this
  readme.txt file attached.

- This font comes "as is" with NO warranty whatsoever. I am not 
  and can not be held responsible for any damage incurred to 
  any computer after installing and/or using this font.

NOTES
I made this font for my first-born son, Alberto.
If you like this font, feel free to send me an e-mail.
[you can see Alberto pressing "�" key, while using Albertino
font, of course]

